import React from "react";

const ModalContext = React.createContext();

export default ModalContext;
