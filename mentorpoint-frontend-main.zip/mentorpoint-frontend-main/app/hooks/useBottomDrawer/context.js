import { createContext } from "react";

const BottomDrawerContext = createContext();

export default BottomDrawerContext;
