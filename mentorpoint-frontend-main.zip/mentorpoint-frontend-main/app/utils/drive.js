const driveURL = "https://drive.google.com/uc?export=view&id=";
export default driveURL;
