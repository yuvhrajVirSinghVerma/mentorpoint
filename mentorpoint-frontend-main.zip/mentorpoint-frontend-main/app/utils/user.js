const user = {
  name: "Dnyaneshwar",
  email: "abc@123.com",
  headline: "SDE at Amazon",
  bio: "I am Mentor",
  skills: ["C++", "Java", "Python"],
};

export default user;
