const androidClientID =
  "150246932117-o66hnn4tbiunmvje2irfimftjepb7d21.apps.googleusercontent.com";

const webClientId =
  "150246932117-jti1qtk8so325l2b5lf1gimpq8fl78pg.apps.googleusercontent.com";

export default { androidClientID, webClientId };
